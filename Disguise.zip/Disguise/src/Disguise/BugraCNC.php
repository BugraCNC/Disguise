<?php

namespace Disguise;

use pocketmine\plugin\PluginBase;
use pocketmine\command\{CommandSender, Command};
use Disguise\form\SimpleForm;
use Disguise\form\CustomForm;
use Disguise\form\ModalForm;
use Disguise\form\Form;

class BugraCNC extends PluginBase{
	
	public function onCommand(CommandSender $sender, Command $kmt, String $label, array $args): bool{
		$isim = $sender->getName();
		    if($kmt->getName() == "disguise") {
				$isimler = array(0 => "AslanKral", 1 =>"UykucuPanda", 2 =>"BetulCicek", 3 =>"PvP_King", 4 =>"DondurmaliTost", 5 =>"dilencidegilim01", 6 => "SungerPOP", 7 => "SeniSeviyorum", 8 =>"İrmakYaren", 9 =>"SudeTekin", 10 =>"babaoyunda06");
				$disguise = $isimler[array_rand($isimler)];
				if($sender->isOp()) {
					if($sender->isOp()){
						$sender->sendMessage("§8----- §cEM Disguise System§8 -----\n\n§7İsminiz Başarı İle Değiştirildi!\n§eYeni İsminiz§7:§7 ". $disguise. "\n\n§8----- §cEM Disguise System§8 -----");
						$sender->setNameTag($disguise);
						$sender->setDisplayName($disguise);
					}
				}
			}else{
				if($kmt->getName() == "undisguise") {
					if($sender->isOp()) {
						$sender->sendMessage("§8----- §cEM Disguise System§8 -----\n\n§7İsminiz Sıfırlandı!\n\n§8----- §cEM Disguise System§8 -----");
						$sender->setNameTag($isim);
						$sender->setDisplayName($isim);
					}
				}
			}
		return true;
	}
}